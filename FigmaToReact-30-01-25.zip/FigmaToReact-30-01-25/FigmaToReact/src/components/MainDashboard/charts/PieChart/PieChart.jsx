import React from 'react'
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";

Chart.register(ArcElement, Tooltip, Legend);

const data = {
  labels: ["Total Order", "Customer Growth", "Total Revenue"],
  datasets: [
    {
      data: [81, 22, 62],
      backgroundColor: ["#ff6384", "#36a2eb", "#4bc0c0"],
      hoverBackgroundColor: ["#ff4561", "#0099ff", "#008b8b"],
    },
  ],
};

function PieChart() {
    return <Doughnut data={data} />;
}

export default PieChart
