import React from 'react'
import TitleDashboard from './title/TitleDashboard'
import StatsCard from './StatsCard/StatsCard'

function DashBoard() {
  return (
    <>
      <TitleDashboard/>
      <StatsCard/>
    </>
  )
}

export default DashBoard
