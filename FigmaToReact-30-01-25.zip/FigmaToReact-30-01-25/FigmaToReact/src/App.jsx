import './App.css'
import AdminPage from './layout/AdminLayout'

function App() {

  return (
    <>
    <AdminPage/>
    </>
  )
}

export default App
