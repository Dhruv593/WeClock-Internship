import React from 'react'

function RevenueGraph() {
  return (
    <div>
      
    </div>
  )
}

export default RevenueGraph
