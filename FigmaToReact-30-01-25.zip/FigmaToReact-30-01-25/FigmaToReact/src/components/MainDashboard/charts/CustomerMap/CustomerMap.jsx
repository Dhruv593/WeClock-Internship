import React from 'react'

function CustomerMap() {
  return (
    <div>
      
    </div>
  )
}

export default CustomerMap
