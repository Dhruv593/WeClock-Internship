import React from 'react'

function Separator() {
  return (
    <div className="h-[56px] bg-[#dddee8] w-[2px]"></div>
  )
}

export default Separator
