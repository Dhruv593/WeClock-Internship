import React from 'react'

function AllChart() {
  return (
    <div>
      
    </div>
  )
}

export default AllChart
